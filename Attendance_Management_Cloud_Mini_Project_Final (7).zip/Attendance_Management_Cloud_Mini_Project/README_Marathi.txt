ATTENDANCE MANAGEMENT SYSTEM - CLOUD COMPUTING MINI PROJECT
============================================================

फाइल्स:
- index.html       : Login page
- login.js         : Firebase Authentication login
- firebase.js      : Firebase project connection
- dashboard.html/js: Dashboard counts
- students.html/js : Student add/search/delete
- attendance.html/js: Attendance present/absent save
- report.html/js   : Date-range report and CSV export
- style.css        : Website styling
- firestore.rules  : Firestore security rules (Firebase Console मध्ये copy करा)

कसे चालवायचे:
1. या ZIP मधील सर्व फाइल्स एका नवीन folder मध्ये Extract करा.
2. VS Code मध्ये तो folder Open Folder करा.
3. Live Server extension install असेल तर index.html वर right-click > Open with Live Server करा.
   file:// ने उघडू नका; ES modules साठी Live Server वापरा.
4. Firebase Console > Authentication > Sign-in method मध्ये Email/Password Enable करा.
5. Authentication > Users > Add user वापरून Email आणि Password तयार करा.
6. Firestore Database मध्ये `students` आणि `Attendance` हे collection names case-sensitive आहेत.
   सुरुवातीला Students पेजवरून नवीन student add करा.
7. Firestore Database > Rules मध्ये firestore.rules मधील code paste करून Publish करा.
   लक्षात ठेवा: या rules मुळे कोणताही signed-in user student/attendance data बदलू शकतो.
   Mini project/demo साठी आहे; production साठी role-based rules लागू करा.
8. Login page वर Firebase user चे Email आणि Password वापरा.

महत्त्वाच्या नोंदी:
- firebase.js मध्ये दिलेला config तुझ्या आधीच्या project मधून घेतला आहे. Project बदलल्यास स्वतःचा Firebase config वापर.
- Web config मध्ये apiKey असणे सामान्य आहे; पण Firestore security Rules योग्य असणे आवश्यक आहे.
- Dashboard/Students/Attendance/Report pages login नसल्यास login page वर परत पाठवतात.
- Attendance document ID date_studentID वापरतो, त्यामुळे त्याच student ची त्याच दिवशी duplicate entry तयार होत नाही.
- Reports attendance records ज्या दिवसांसाठी mark केले आहेत त्यावर percentage मोजतात; नोंद नसलेले दिवस total मध्ये धरले जात नाहीत.
- QR generator आणि camera scanner दोन्ही समाविष्ट आहेत. Camera साठी localhost/HTTPS आणि browser camera permission आवश्यक आहे.


QR ATTENDANCE FEATURE (added)
1. Dashboard madhun QR Attendance var ja ani Generate QR Code kara.
2. Scan QR page var student select kara ani Start Camera daba. Camera permission allow kara.
3. QR scan karanyasathi camera dusrya screen varil QR code kade kara. Localhost/HTTPS vapra.
4. Ekach student/date sathi duplicate record asel tar transaction duplicate attendance rokhte.
Note: Student select karun QR scan karne hi demo workflow aahe; production sathi authenticated student identity verification ani stricter Firestore rules vapra.


FINAL TESTING CHECKLIST
=======================
1. Students पेजवर किमान 2 demo students add करा.
2. Mark Attendance पेजवर आजची तारीख निवडून वेगवेगळ्या students साठी Present/Absent save करा.
3. Dashboard वर Total Students, Present Today, Absent Today आणि Attendance Today तपासा. Attendance Today = Present Today / Total Students x 100.
4. Attendance Report मध्ये date range निवडून Generate Report करा. Attendance % = Present / (Present + Absent) x 100; report फक्त नोंद केलेले दिवस मोजतो.
5. Export CSV दाबून report file डाउनलोड होते का तपासा.
6. QR Attendance पेजवर आजचा QR generate करा. Scan QR पेजवर student निवडा, Start Camera करा आणि QR scan करा.
7. त्याच student आणि date साठी पुन्हा scan केल्यास duplicate message येणे अपेक्षित आहे.
8. Mobile layout तपासण्यासाठी Chrome DevTools मधील device toolbar वापरा किंवा मोबाईलवर HTTPS-hosted site उघडा.

टीप: ही demo/miniproject application आहे. QR code मधील date बदलून जुन्या/भविष्यातील attendance टाळण्यासाठी production आवृत्तीत server-side validation आणि stricter security rules आवश्यक आहेत.
